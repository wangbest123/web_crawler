package com.cn.pojo;

/**
 * Created by wangmeng on 2019/6/14.
 */
public class HTML {
    private String html;

    public String getHtml() {
        return html;
    }

    public void setHtml(String html) {
        this.html = html;
    }
}
