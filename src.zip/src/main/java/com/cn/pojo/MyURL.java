package com.cn.pojo;

/**
 * Created by wangmeng on 2019/6/14.
 */
public class MyURL {
    String url;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
