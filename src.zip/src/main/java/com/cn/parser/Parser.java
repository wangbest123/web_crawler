package com.cn.parser;

/**
 * Created by wangmeng on 2019/6/14.
 */
public interface Parser {
}
