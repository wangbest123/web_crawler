package com.cn.tools;

/**
 * Created by wangmeng on 2019/6/14.
 */
public class FileOp {

    public static void toCsv(String fileName){
        return;
    }

    public static void toExcel(String fileName){
        return;
    }

    public static void tTxt(String fileName){
        return;
    }

    public static void readCsv(String fileName){
        return;
    }

    public static void readExcel(String fileName){
        return;
    }

    public static void toTxt(String fileName){
        return;
    }
}
