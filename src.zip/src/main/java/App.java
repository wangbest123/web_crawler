/**
 * Created by wangmeng on 2019/6/14.
 */
public class App {
    public static void main(String[] args) {
        String homeUrl = "https://www.jiazhao.com/news_21/";


    }
}
